<!DOCTYPE TS><TS version="1.1" language="de">
<context>
    <name>QPushButton</name>
    <message>
        <source>Hello world!</source>
        <translation>Hallo Welt!</translation>
    </message>
    <message numerus="yes">
        <source>Hello %n world(s)!</source>
        <translation>
            <numerusform>Hallo %n Welt!</numerusform>
            <numerusform>Hallo %n Welten!</numerusform>
        </translation>
    </message>
</context>
</TS>

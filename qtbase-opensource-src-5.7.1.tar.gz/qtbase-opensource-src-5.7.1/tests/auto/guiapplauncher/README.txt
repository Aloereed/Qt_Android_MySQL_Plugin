The guiapplauncher from the qtqa repository uses the data in this
directory to do its testing for this module.

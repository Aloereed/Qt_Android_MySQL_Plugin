<?xml version="1.0" encoding="utf-8"?>
<!DOCTYPE TS>
<TS version="2.0" language="de">
  <dependencies>
    <dependency catalog="hellotr_la"/>
  </dependencies>
  <context>
    <name>QPushButton</name>
    <message>
        <source>It's a small world</source>
        <translation>Es ist eine kleine Welt</translation>
    </message>
  </context>
</TS>
